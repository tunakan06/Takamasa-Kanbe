#include "Animation.h"

Animation::Animation(){

	mTextParam	= new TextParam();

	mBinFile	= new BinaryFile();

}

Animation::~Animation(){}

